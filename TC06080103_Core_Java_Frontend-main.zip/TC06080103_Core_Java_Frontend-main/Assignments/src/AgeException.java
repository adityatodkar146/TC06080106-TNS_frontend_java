
public class AgeException extends Exception 
{
	public AgeException()
	{
		super("invalid age for voter");
	}

}
