
public class Tile
{
	private int length;

	public Tile(int length) 
	{
		this.length = length;
	}

	public int getLength() {
		return length;
	}

}
