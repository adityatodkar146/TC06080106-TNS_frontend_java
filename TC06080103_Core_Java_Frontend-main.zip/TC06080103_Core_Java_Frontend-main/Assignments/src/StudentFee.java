
public interface StudentFee 
{
	void getFee() throws InvalidFeeException;
}
