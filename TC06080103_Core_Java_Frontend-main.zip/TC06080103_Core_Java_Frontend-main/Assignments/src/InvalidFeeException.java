
public class InvalidFeeException extends Exception 
{
	public InvalidFeeException(String msg)
	{
		super(msg);
	}
}
