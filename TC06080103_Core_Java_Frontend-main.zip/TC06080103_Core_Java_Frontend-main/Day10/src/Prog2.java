
public class Prog2 
{
	public static void main(String[] args) 
	{
		Integer x =10;
		double y =x;
		System.out.println(y);
		
	}

}
