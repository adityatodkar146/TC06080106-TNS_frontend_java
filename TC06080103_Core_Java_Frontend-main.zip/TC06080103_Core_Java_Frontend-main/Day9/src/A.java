
public class A 
{
	public double div(int a,int b)
	{
		double d = (double)a/b;
		return d;
	}

}
