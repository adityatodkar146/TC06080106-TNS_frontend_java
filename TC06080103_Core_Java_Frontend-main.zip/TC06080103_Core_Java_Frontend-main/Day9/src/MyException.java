
public class MyException extends Exception
{
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "My exception ocuured";
	}
	

}
