
public abstract class Popcorn 
{
	public abstract void taste();
}
