
public class Outer4
{
	private int i=10;
	
	class Inner
	{
		int no=111;
		public void get()
		{
			System.out.println("No = "+no);
		}
		
		public static void main(String[] args) 
		{
			System.out.println("Hello");
			
		}
	}
	
	
}