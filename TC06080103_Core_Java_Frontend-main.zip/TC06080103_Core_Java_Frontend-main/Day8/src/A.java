
public class A extends Test
{
	public static void main(String[] args) 
	{
		
		Popcorn p = new Popcorn ()
		{
			public void taste()
			{
				System.out.println("cheezy");
			}
					
		};
		p.taste();
		
	}
	

}
