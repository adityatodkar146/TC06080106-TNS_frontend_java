import java.util.Enumeration;
import java.util.*;


public class Prog4 
{
	public static void main(String[] args) 
	{
		/*
		Vector<Integer> v = new Vector<Integer> ();
		System.out.println(v.capacity());
		System.out.println(v.size());
		
		for(int i=0;i<10;i++)
		{
			v.add(i);
		}
		System.out.println(v);
		System.out.println(v.capacity());
		System.out.println(v.size());
		
		
		Enumeration <Integer> x = v.elements();
		System.out.println("Start");
		
		while (x.hasMoreElements())
		{
			int i= x.nextElement();
			if(i%2==0)
				System.out.println(i);
		}
		System.out.println(v);	
		
		System.out.println("Start");
		Iterator <Integer> i= v.iterator();
		while(i.hasNext())
		{
			int n = i.next();
			if (n%2==0)
				System.out.println(n);
		}
		
		
		ListIterator <String> itr = v.listIterator();
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}