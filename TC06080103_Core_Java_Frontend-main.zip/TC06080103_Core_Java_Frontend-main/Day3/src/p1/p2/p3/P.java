package p1.p2.p3;

public class P {

	public void m1() {
		System.out.println("Method from P Class");
	}
}
