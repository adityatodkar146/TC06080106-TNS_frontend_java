package p1.p2.p3;

public class fnobj 
{
	public static void main(String [] args)
	{
		
	}
}
