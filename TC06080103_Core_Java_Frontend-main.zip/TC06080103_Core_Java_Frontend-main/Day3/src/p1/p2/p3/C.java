package p1.p2.p3;

public class C
{
	public static void main(String args [])
	{
		A a = new A();
		System.out.println(a.no);
	}

}