package p1.p2;
import p1.p2.p3.A;

public class B extends A
{
	public static void main(String args [])
	{
		B a = new B();
		System.out.println(a.no);
	}

}
