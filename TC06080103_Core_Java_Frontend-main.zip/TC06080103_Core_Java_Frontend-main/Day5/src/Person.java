import java.util.Scanner;
public class Person 
{
	private int id;
	private String name;
	protected Scanner sc = new Scanner(System.in);
	
	public Person()
	{
		
	}

	public Person(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	
	

}
