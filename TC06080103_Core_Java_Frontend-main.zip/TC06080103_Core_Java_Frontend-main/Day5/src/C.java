
public class C 
{
	public C(){
		System.out.println("Default constructor of C");
	}
	
	public C(int a)
	{
		System.out.println("Parameterized constructor of A");
	}

}
