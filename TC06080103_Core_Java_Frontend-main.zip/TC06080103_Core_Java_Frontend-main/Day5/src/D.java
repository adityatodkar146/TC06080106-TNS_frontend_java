
public class D extends C
{
	public D()
	{
		System.out.println("Child def");
	}

}
