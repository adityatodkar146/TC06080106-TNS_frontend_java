
public class atm {

}
