
interface i1
{
	void meth1();
}


public class Pract5 
{
	public static void main(String[] args) 
	{
		i1 x = ()->{System.out.println("Hiee");};
		x.meth1();
		
		System.out.println(Integer.compare(310,35));
		
	}

}
