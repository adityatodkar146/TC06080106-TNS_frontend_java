
public abstract class Bank 
{
	public abstract float getRateOfInterest();
	
	public void msg()
	{
		System.out.println("Bank");
	}

}
