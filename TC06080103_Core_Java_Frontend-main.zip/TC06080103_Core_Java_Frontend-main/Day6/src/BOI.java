
public class BOI extends Bank
{

	@Override
	public float getRateOfInterest() {
		return 6.7f;
	}
	
	public void msg()
	{
		System.out.println("BOI");
	}
	
	

}
