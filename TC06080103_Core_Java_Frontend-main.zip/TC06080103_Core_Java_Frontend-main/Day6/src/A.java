
public class A 
{
	A get()
	{
		return this;
	}
	void msg()
	{
		System.out.println("Hello A");
	}
}
