
public interface Arithmetic 
{
	

}
